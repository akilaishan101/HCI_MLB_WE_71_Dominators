<?php
namespace DuplicatorPro\Guzzle\Service\Exception;

class ServiceNotFoundException extends ServiceBuilderException {}
