<?php

class DUP_PRO_NoScanFileException extends Exception {}

class DUP_PRO_EmptyScanFileException extends Exception {}

class DUP_PRO_JsonDecodeException extends Exception {}

class DUP_PRO_NoFileListException extends Exception {}

class DUP_PRO_EmptyFileListException extends Exception {}

class DUP_PRO_NoDirListException extends Exception {}

class DUP_PRO_EmptyDirListException extends Exception {}