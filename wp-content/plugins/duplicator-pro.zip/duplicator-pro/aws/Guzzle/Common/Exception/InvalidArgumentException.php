<?php
namespace DuplicatorPro\Guzzle\Common\Exception;

defined("ABSPATH") or die("");

class InvalidArgumentException extends \InvalidArgumentException implements GuzzleException {}
