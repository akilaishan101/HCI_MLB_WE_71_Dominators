<?php
if (!defined("ABSPATH") && !defined("DUPXABSPATH")) 
    die("");
if (!class_exists('DupProSnapLib_32BitSizeLimitException')):
class DupProSnapLib_32BitSizeLimitException extends Exception {}
endif;